#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <unordered_map>
#include <cctype>
#include <algorithm>
using namespace std;

string toLower(string str) {
    transform(str.begin(), str.end(), str.begin(), ::tolower);
    return str;
}

string removePunctuation(const string& str) {
    string cleaned = "";
    for (char ch : str) {
        if (!ispunct(ch)) {
            cleaned += ch;
        }
    }
    return cleaned;
}

vector<string> splitIntoWords(const string& line) {
    stringstream ss(line);
    string word;
    vector<string> words;
    while (ss >> word) {
        words.push_back(word);
    }
    return words;
}

vector<string> processFile(const string& filename) {
    ifstream file(filename);
    string line;
    vector<string> words;
    if (!file.is_open()) {
        cerr << "Error: Cannot open file " << filename << endl;
        return words;
    }
    while (getline(file, line)) {
        line = toLower(removePunctuation(line));
        vector<string> lineWords = splitIntoWords(line);
        words.insert(words.end(), lineWords.begin(), lineWords.end());
    }
    file.close();
    return words;
}

unordered_map<string, int> countWordFrequency(const vector<string>& words) {
    unordered_map<string, int> freqMap;
    for (const string& word : words) {
        freqMap[word]++;
    }
    return freqMap;
}

int countCommonWords(const unordered_map<string, int>& map1, const unordered_map<string, int>& map2) {
    int common = 0;
    for (const auto& entry : map1) {
        if (map2.find(entry.first) != map2.end()) {
            common++;
        }
    }
    return common;
}

string getVerdict(double similarity) {
    if (similarity >= 80.0)
        return "Highly Likely Plagiarized";
    else if (similarity >= 50.0)
        return "Possibly Plagiarized";
    else
        return "Likely Original";
}

void saveReport(double similarity, const string& verdict) {
    ofstream report("report.txt");
    if (!report) {
        cerr << "Error: Could not create report.txt\n";
        return;
    }
    report << "Plagiarism Report\n";
    report << "------------------\n";
    report << "Similarity Score: " << similarity << "%\n";
    report << "Verdict: " << verdict << "\n";
    report.close();
    cout << "\nReport saved to report.txt ✅\n";
}

int main() {
    vector<string> words1 = processFile("file1.txt");
    vector<string> words2 = processFile("file2.txt");

    unordered_map<string, int> freq1 = countWordFrequency(words1);
    unordered_map<string, int> freq2 = countWordFrequency(words2);

    int commonWords = countCommonWords(freq1, freq2);
    int totalUnique = freq1.size() + freq2.size();
    double similarity = (2.0 * commonWords / totalUnique) * 100;
    string verdict = getVerdict(similarity);

    cout << "\nPlagiarism Check Result:\n";
    cout << "--------------------------\n";
    cout << "File 1 Unique Words: " << freq1.size() << endl;
    cout << "File 2 Unique Words: " << freq2.size() << endl;
    cout << "Common Words: " << commonWords << endl;
    cout << "Similarity Score: " << similarity << "%\n";
    cout << "Verdict: " << verdict << "\n";

    saveReport(similarity, verdict);

    return 0;
}