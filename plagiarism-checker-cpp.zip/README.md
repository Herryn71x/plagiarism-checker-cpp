# 🕵️‍♂️ Plagiarism Checker in C++

A C++ project that checks for plagiarism by comparing two text files using word frequency hashing and calculates a similarity score.

## 🚀 Features
- Reads two `.txt` files
- Cleans and tokenizes words (lowercase + no punctuation)
- Counts word frequencies using hash maps (`unordered_map`)
- Calculates similarity score based on common words
- Gives a verdict: Original / Possibly Plagiarized / Highly Plagiarized
- Saves report to `report.txt`

## 📂 Folder Structure
```
📁 plagiarism-checker-cpp/
├── main.cpp          ← Main source code
├── file1.txt         ← Essay input 1
├── file2.txt         ← Essay input 2
└── report.txt        ← Generated output (auto-created)
```

## 💻 How to Run (Using VS Code)
1. Open folder in VS Code
2. Make sure C++ (`g++`) is installed
3. Open terminal and run:
   ```bash
   g++ -std=c++17 main.cpp -o checker.exe
   checker.exe
   ```
4. Output and similarity score will be printed, and saved to `report.txt`

## ✅ Sample Verdict
```
File 1 Unique Words: 28
File 2 Unique Words: 27
Common Words: 18
Similarity Score: 64.7%
Verdict: Possibly Plagiarized
```

## 📌 Technologies Used
- C++
- STL (`unordered_map`, `vector`, `fstream`)
- Basic NLP-style text preprocessing

## 📜 License
MIT License. Free to use and modify.